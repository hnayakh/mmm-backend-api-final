export const religion = [
  {
    id: 'Hindu',
    text: 'Hindu',
  },
  {
    id: 'Muslim',
    text: 'Muslim',
  },
  {
    id: 'Christian',
    text: 'Christian',
  },
  {
    id: 'Jain',
    text: 'Jain',
  },
  {
    id: 'Sikh',
    text: 'Sikh',
  },
  {
    id: 'Buddhist',
    text: 'Buddhist',
  },
  {
    id: 'Parsi',
    text: 'Parsi',
  },
  {
    id: 'Jewish',
    text: 'Jewish',
  },
  {
    id: 'Other',
    text: 'Other',
  },
  {
    id: 'No Religion',
    text: 'No Religion',
  },
  {
    id: 'Spiritual - not religious',
    text: 'Spiritual - not religious',
  },
];
