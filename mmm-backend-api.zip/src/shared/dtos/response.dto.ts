export class ResponseDto {
  status: number;
  message: string;
  data: any;
  type: string;
}
