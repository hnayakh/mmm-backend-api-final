export const postedBy = [
  {
    id: 'Self',
    text: 'Self',
  },
  {
    id: 'Parent / Guardian',
    text: 'Son',
  },
  {
    id: 'Parent / Guardian',
    text: 'Daughter',
  },
  {
    id: 'Sibling',
    text: 'Brother',
  },
  {
    id: 'Sibling',
    text: 'Sister',
  },
  {
    id: 'Friend',
    text: 'Friend',
  },
  {
    id: 'Other',
    text: 'Relative',
  },
];
